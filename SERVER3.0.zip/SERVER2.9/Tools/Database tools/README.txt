If you are having problems with remix's tools ensure you have a 32bit 
odbc entry, (does not apply if you have a 32bit system) 

So the tools can successfully connect to the database, if you 
are getting an error about ARButton.ocx run remixfix.cmd