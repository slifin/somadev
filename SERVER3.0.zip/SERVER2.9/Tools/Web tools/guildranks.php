<? include("conf.php"); ?>
<html>
<head>
<title>Guild War Ranks</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#333333" text="#FFFFFF" link="#FFFFFF">
<p>&nbsp;</p>
<div align="center">
  <p><font color="#FFFFFF" size="4" face="Geneva, Arial, Helvetica, sans-serif">GUILD WAR RANKS </font></p>
  <table width="388" border="0">
    <tr>
      <td width="110"><div align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Guild Name </strong></font></div></td>
      <td width="93"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Wins</strong></font></div></td>
      <td width="60"><div align="center"><strong><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Draws</font></strong></div></td>
      <td width="107"><div align="center"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Losses</strong></font></div></td>
    </tr>
    <tr>
      <td><div align="left"><font size="2">
        <?

$humanquery = "SELECT strguildname FROM guild_war_score ORDER BY swin DESC ";


$humanresult = mssql_query($humanquery,$conn);
$humannum = mssql_num_rows($humanresult);
$humani = 0;
while ($humani < $humannum)
{
$humanname = mssql_result($humanresult,$humani,"strguildname");
$realnum = $humani + 1;
echo "$humanname<br>";
$humani++;
}
?>
      </font></div></td>
      <td><div align="center"><font size="2">
        <?

$humanquery = "SELECT swin FROM guild_war_score ORDER BY swin DESC";


$humanresult = mssql_query($humanquery,$conn);
$humannum = mssql_num_rows($humanresult);
$humani = 0;
while ($humani < $humannum)
{
$humanname = mssql_result($humanresult,$humani,"swin");
$realnum = $humani + 1;
echo "$humanname<br>";
$humani++;
}
?>
      </font></div></td>
      <td><div align="center"><font size="2">
        <?

$humanquery = "SELECT sdraw FROM guild_war_score ORDER BY swin DESC";


$humanresult = mssql_query($humanquery,$conn);
$humannum = mssql_num_rows($humanresult);
$humani = 0;
while ($humani < $humannum)
{
$humanname = mssql_result($humanresult,$humani,"sdraw");
$realnum = $humani + 1;
echo "$humanname<br>";
$humani++;
}
?>
      </font></div></td>
      <td><div align="center"><font size="2">
        <?

$humanquery = "SELECT slose FROM guild_war_score ORDER BY swin DESC";


$humanresult = mssql_query($humanquery,$conn);
$humannum = mssql_num_rows($humanresult);
$humani = 0;
while ($humani < $humannum)
{
$humanname = mssql_result($humanresult,$humani,"slose");
$realnum = $humani + 1;
echo "$humanname<br>";
$humani++;
}
?>
      </font></div></td>
    </tr>
  </table>
  <div align="center">
    <div align="center">
      <table width="221" height="27" border="0">
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td width="455"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Sylver, <a href="http://sylver.teamsykotic.com">Sylver.teamsykotic.com</a></font><font size="2"> </font></div></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<blockquote>
  <p align="center">&nbsp;</p>
</blockquote>
</body>
</html>