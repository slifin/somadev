<?php 

$odbc = 'soma';
$user = 'soma';
$pass = 'soma';

$conn=odbc_connect($odbc, $user, $pass);
if (!$conn)
  {exit("Connection Failed: " . $conn);}

?>