<?php

// << -------------------------------------------------------------------- >>
// >> Agile knights Registration Page
// >> Copyright by Agile knights & Gaming Network all rights reserved.
// >> REGISTER . PHP File - User Registration Agile knights
// >> Started : July 01, 2005
// >> Edited  : June 03, 2005
// << -------------------------------------------------------------------- >>

include("config.php");

if (isset($_POST['AddAccount'])) {

 $username = $_POST['Username'];
 $password = $_POST['Password'];
 $strname = $_POST['strName'];
 $mail = $_POST['Email'];
 $wSerial = $_POST['wSerial'];

 if (empty($username) || empty($password) || empty($strname) || empty($mail) || empty($wSerial)) {
  echo '<b>You must fill out all fields, before submitting!</b>';
 }
 elseif (!preg_match('/^[\w@\.\- ]+$/',"$username.$password.$strname.$wSerial")) {

  echo '<b>Invalid data entered</b>';
 }
 elseif (!eregi("^[0-9a-z]([-_.]?[0-9a-z])*@[0-9a-z]([-.]?[0-9a-z])*\.[a-z]{2,4}$","$mail")) {

  echo '<b>Your email is entered incorrecty.</b>';
 }
  else {

   $uresult = odbc_exec($conn, "SELECT strUserId FROM NGSCUSER WHERE strUserId = '$username'");
   $eresult = odbc_exec($conn, "SELECT strEmail  FROM NGSCUSER WHERE strEmail = '$mail'");

   if (odbc_num_rows($uresult) > 0) {
    
    echo "<b>Username is already taken.</b>";
   }
   elseif (odbc_num_rows($eresult) > 0) {
    echo "<b>Email is already taken.</b>";
   }
    elseif (strlen($_POST['wSerial']) < 5) {
     echo "<b>Your Security code must be 5 digits long.</b>";
 }
   else {
    $accquery = odbc_exec($conn, "INSERT INTO NGSCUSER (strUserId,strPasswd,strName,strEmail,wSerial) VALUES ('$username','$password','$strname','$mail','$wSerial')");
    echo "<b>Your Account has now been created.</b>";
   }

 }

 }

?>
<title>::Agile knights Registration Page::</title><body bgcolor="#000000" text="#FFFFFF">
<div align="center">
</div>
<table background="servak/images/ak_edit_1.jpg" width="568" border="0" align="center">
  <!--DWLayoutTable-->
  <tr>
    <td width="115" height="100">&nbsp;</td>
    <td width="347">&nbsp;</td>
    <td width="92">&nbsp;</td>
  </tr>
  <tr>
    <td height="233">&nbsp;</td>
    <td valign="top" class="mytext"> <u><font color="#FFFFFF"></font></u><br>
      <form action="register.php" method="post">
        <table width="347" border="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="175" height="21"><font color="#FFFFFF">Username: </font></td>
            <td width="120" valign="top"><input type="text" name="Username" height="21" maxlength="12"

style="width: 120px;"> </td>
            <td width="38">&nbsp;</td>
          </tr>
          <tr>
            <td height="21"><font color="#FFFFFF">Password: </font></td>
            <td valign="top"><input type="password" name="Password" height="21" maxlength="12"

style="width: 120px;"></td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="21" valign="top"><font color="#FFFFFF">Security Code:
              (5 Digits)</font></td>
            <td valign="top"><input type="password" name="wSerial" height="21" maxlength="5"

style="width: 120px;"></td>
            <td></td>
          </tr>
          <tr>
            <td height="21" valign="top"><font color="#FFFFFF">Full Name: </font></td>
            <td valign="top"><input type="text" name="strName" height="21" maxlength="20"

style="width: 120px;"></td>
            <td></td>
          </tr>
          <tr>
            <td height="21" valign="top"><font color="#FFFFFF">Email Address:
              </font></td>
            <td valign="top"><input type="text" name="Email" height="21" maxlength="50"

style="width: 120px;"></td>
            <td></td>
          </tr>
          <tr>
            <td height="21"></td>
            <td></td>
            <td></td>
          <tr>
            <td height="21"></td>
            <td valign="top"><input type= "submit" value="Submit" name="AddAccount"></td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="117">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
