<?php

// << -------------------------------------------------------------------- >>
// >> Agile knights Staff Online Page
// >> Copyright by Agile knights & Gaming Network all rights reserved.
// >> REGISTER . PHP File - Staff Online Agile knights
// >> Started : July 01, 2005
// >> Edited  : June 07, 2005
// << -------------------------------------------------------------------- >>

include("conf.php");
$query = "SELECT * FROM CURRENTPLAYER WHERE PLAYERNAME = 'STAFFCHARACTER' OR (PLAYERNAME = 'STAFFCHARACTER')";
$result = mssql_query($query);
$users = mssql_num_rows($result);

echo "Current Staff Online: $users";
?>
<title>::STAFF ONLINE - POWERED BY GETDOWN! GAMING::</title>
<body bgcolor="#000000" text="#FFFFFF">
<div align="center"></div>
