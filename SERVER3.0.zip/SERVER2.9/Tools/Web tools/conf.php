<?php

eval(base64_decode('JGNvZGVsb2NrX2NvZGU9IkNnb0tDZ29LIjsgJGNvZGVsb2NrX2NvZGU9c3RyX3JlcGxhY2UoIkAiLCJDQWciLCAkY29kZWxvY2tfY29kZSk7ICRjb2RlbG9ja19jb2RlPXN0cl9yZXBsYWNlKCIhIiwgIlc1IiwgJGNvZGVsb2NrX2NvZGUpOyAkY29kZWxvY2tfY29kZT1zdHJfcmVwbGFjZSgiKiIsICJDQWdJIiwgJGNvZGVsb2NrX2NvZGUpOyAkY29kZWxvY2tfY29kZT1iYXNlNjRfZGVjb2RlKCRjb2RlbG9ja19jb2RlKTsgZXZhbCgkY29kZWxvY2tfY29kZSk7IAo='));


//MSSQL Host IP
$db_host = 'localhost\SQLExpress';

//MSSQL Username
$db_user = 'soma';

//MSSQL Password
$db_pass = 'soma';

//MSSQL Database
$db_name = 'soma';

$conn = mssql_connect($db_host,$db_user,$db_pass);
mssql_select_db($db_name,$conn);
?>