<body bgcolor="#000000" text="#FFFFFF">
<?

// << -------------------------------------------------------------------- >>
// >> Agile knights Players online & Registered Members Page
// >> Copyright by Agile knights & Gaming Network all rights reserved.
// >> REGISTER . PHP File - Players online & Registered Members Agile knights
// >> Started : July 01, 2005
// >> Edited  : June 07, 2005
// << -------------------------------------------------------------------- >>

include("conf.php");
$query = "SELECT * FROM CURRENTUSER";
$result = mssql_query($query);
$users = mssql_num_rows($result);

echo "Players Online: $users";
?>
<p></p>
<?
$query = "SELECT * FROM NGSCUSER";
$result = mssql_query($query);
$users = mssql_num_rows($result);

echo "Current Registered Users: $users";
?>