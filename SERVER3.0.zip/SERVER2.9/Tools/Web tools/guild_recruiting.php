<?php include("conf.php"); ?>
<html>
<head>
<title>Guild Recruiting Page</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#333333" text="#FFFFFF" link="#FFFFFF">
<p>&nbsp;</p>
<div align="center">
  <p><font color="#FFFFFF" size="4" face="Geneva, Arial, Helvetica, sans-serif">GUILD Recruiting Page!</font></p>
  <table width="600" border="1">
    <tr>
      <td width="102"><div align="left"><font size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong><font color="#FF0000">Guild Name </font></strong></font></div></td>
      <td width="387"><div align="left"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">Advertisement</font></strong></div></td>
      <td width="82"><div align="left"><strong><font color="#FF0000" size="2" face="Verdana, Arial, Helvetica, sans-serif">Guild Type</font></strong></div></td>
      <td width="11"><div align="left"></div></td>
    </tr>

        <?php
$result = mssql_query("SELECT * FROM guild ORDER BY strguildname",$conn);
if(mssql_num_rows($result))
{
	while($row1 = mssql_fetch_assoc($result)) { $array1[] = $row1; }
	for($i = 0; $i < mssql_num_rows($result); $i++)
	{    
		echo '<tr><td><div align="left"><font size="2">';
		echo $array1[$i]['strGuildName'];
		echo '</font></div></td><td><div align="left"><font size="2">';
		echo $array1[$i]['strInfo'];
		echo '</font></div></td><td><div align="left"><font size="2">';
		$class = ( $array1[$i]['sGuildClass'] == '10') ? "Devil" : "Human";
		echo $class;
		echo '</font></div></td><td><div align="left"></div></td></tr>';
	}
}
?>
  </table>
  <div align="center">
    <div align="center">
      <table width="221" height="27" border="0">
        <tr>
          <td><p>&nbsp;</p>
            <p>&nbsp;</p>
          <p>&nbsp;</p></td>
        </tr>
        <tr>
          <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Thanks to Badger for php help , <a href="http://badgerr.co.uk">Badgerr.co.uk </a></font></div></td>
        </tr>
        <tr>
          <td width="455"><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Sylver, <a href="http://sylver.teamsykotic.com">Sylver.teamsykotic.com</a></font><font size="2"> </font></div></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<blockquote>
  <p align="center">&nbsp;</p>
</blockquote>
</body>
</html>