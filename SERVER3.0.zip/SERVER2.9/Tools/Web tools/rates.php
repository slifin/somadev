<html>
<head>
<title>Soma Rates</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#000000" text="#FFFFFF">
<h2><U>Soma Rates</u></h2><br>
<?php
// << ------------------------------------------------------------------------- >>
// << Soma Rates PHP                                                            >>
// << Version      : 0.40 February 2007                                         >>
// << Author       : Tiffany UK                                                 >>
// << Installation : Place in htdocs (apache) in same location as conf.php      >>
// << ------------------------------------------------------------------------- >>
// << Configuration and SQL Connection / USER / PASS based on conf.php includes >>
// << Experience taken from Raged Soma DB as a 1 X Level reference @ lvl 100    >>
// << Con/Charisma taken from Raged Soma DB as a 1 X Level reference @ 1st      >>
// << table elements                                                            >>
// << Ver 0.30 Added str, dex, int and wis returns but table types need to be   >>
// << set to varchar not ntext                                                  >>
// << Ver 0.40 Added Weapon, magic and make skills                              >>
// << ------------------------------------------------------------------------- >>
// << Returned table currently assume character types are varchar since SQL ODBC>>
// << since other non-textual types require different handling                  >>
// << TODO :                                                                    >>
// <<      1) Try to work out how to use CAST  to ensure Correct SQL returns    >>
// <<          for non-text Tables                                              >>
// << ------------------------------------------------------------------------- >>

// level 100
define("iConst_levelrow", 100);

// HUMAN CONSTANTS
define("iConst_hexp", 62357200);
define("iConst_h_rdexp", 3117860);
define("iConst_h_wdexp", 1247144);

define("iConst_h_con", 30000);
define("iConst_h_cha", 199980);

define("iConst_h_str", 100000);
define("iConst_h_dex", 200000);
define("iConst_h_int", 80000);
define("iConst_h_wis", 160000);

define("iConst_h_weapon", 1650);
define("iConst_h_magic", 1500);
define("iConst_h_make", 3000);

// DEVIL CONSTANTS
define("iConst_dexp", 62357200);
define("iConst_d_rdexp", 3117860);
define("iConst_d_wdexp", 1247144);

// Con and Charisma taken from Raged Soma DB as a 1 X Level reference @ 1st table elements
define("iConst_d_con", 150000);
define("iConst_d_cha", 22220);

define("iConst_d_str", 100000);
define("iConst_d_dex", 1000000);
define("iConst_d_int", 100000);
define("iConst_d_wis", 1000000);

define("iConst_d_weapon", 1650);
define("iConst_d_magic", 1500);

include("conf.php");

//HUMAN
// Retrieve exp from Experience table
$query = "SELECT * FROM tb_exp";
$result = mssql_query($query);
$h_exp = 0;
$h_rdexp = 0;
$h_wdexp = 0;

$h_exp = iConst_hexp / mssql_result($result,iConst_levelrow,"maxexp");
$h_rdexp = iConst_h_rdexp / mssql_result($result,iConst_levelrow,"rdexp");
$h_wdexp = iConst_h_wdexp / mssql_result($result,iConst_levelrow,"wdexp");
printf('Human Exp: %3.2f X,   (Res Death: %3.2f X, Warp Death: %3.2f X)', $h_exp, $h_rdexp, $h_wdexp);
?>
<br>
<?
// Retrieve con and cha from tb_inc_con and tb_inc_cha tables
$h_con = 0;
$h_cha = 0;

$query = "SELECT * FROM tb_inc_con";
$result = mssql_query($query);
$h_con = mssql_result($result,0,"con") / iConst_h_con;
$query = "SELECT * FROM tb_inc_cha";
$result = mssql_query($query);
$h_cha = mssql_result($result,0,"cha") / iConst_h_cha;

printf('Human Con: %3.2f X, Cha : %3.2f X)', $h_con, $h_cha);

?>
<br>
<?
// Retrieve Str, Dex, int and Wis from tb_inc table
$h_str = 0;
$h_dex = 0;
$h_int = 0;
$h_wis = 0;

$query = "SELECT * FROM tb_inc WHERE (sid LIKE '1')";
$result = mssql_query($query);
$h_str = mssql_result($result,0,"str") / iConst_h_str;
$h_dex = mssql_result($result,0,"dex") / iConst_h_dex;
$h_int = mssql_result($result,0,"int") / iConst_h_int;
$h_wis = mssql_result($result,0,"wis") / iConst_h_wis;

printf('Human Str: %3.2f X, Dex: %3.2f X, Int: %3.2f X, Wis: %3.2f X )', $h_str, $h_dex, $h_int, $h_wis);
?>
<br>
<?
// Retrieve Skill items from tb_inc table
$h_axe = 0;
$h_bow = 0;
$h_knux = 0;
$h_spear= 0;
$h_staff = 0;
$h_sword= 0;

$h_darkmg= 0;
$h_whitemg = 0;
$h_bluemg= 0;

$h_wpmake= 0;
$h_ammake = 0;
$h_acmake= 0;
$h_pomake = 0;
$h_ckmake= 0;

$query = "SELECT * FROM tb_inc_exp WHERE (sid LIKE '1')";
$result = mssql_query($query);
$h_axe = mssql_result($result,0,"axe") / iConst_h_weapon;
$h_bow = mssql_result($result,0,"bow") / iConst_h_weapon;
$h_knux = mssql_result($result,0,"knuckle") / iConst_h_weapon;
$h_spear = mssql_result($result,0,"spear") / iConst_h_weapon;
$h_staff = mssql_result($result,0,"staff") / iConst_h_weapon;
$h_sword = mssql_result($result,0,"sword") / iConst_h_weapon;

printf('Human Skill - Axe: %3.2f X, Bow: %3.2f X, Knux: %3.2f X, Spear: %3.2f X, Staff: %3.2f X, Sword: %3.2f X )', $h_axe, $h_bow, $h_knux, $h_spear, $h_staff, $h_sword);

?>
<br>
<?
$h_darkmg = mssql_result($result,0,"darkmg") / iConst_h_magic;
$h_whitemg = mssql_result($result,0,"whitemg") / iConst_h_magic;
$h_bluemg = mssql_result($result,0,"bluemg") / iConst_h_magic;

printf('Human Magic - Black: %3.2f X, White: %3.2f X, Blue: %3.2f X)', $h_darkmg, $h_whitemg, $h_bluemg);

?>
<br>
<?
$h_wpmake = mssql_result($result,0,"wpmake") / iConst_h_make;
$h_ammake = mssql_result($result,0,"ammake") / iConst_h_make;
$h_acmake = mssql_result($result,0,"acmake") / iConst_h_make;
$h_pomake = mssql_result($result,0,"pomake") / iConst_h_make;
$h_ckmake = mssql_result($result,0,"ckmake") / iConst_h_make;

printf('Human Make - Weps: %3.2f X, Armour: %3.2f X, Accs: %3.2f X, Pots: %3.2f X, Cook: %3.2f X)', $h_wpmake, $h_ammake, $h_acmake, $h_pomake, $h_ckmake);

?>
<p></p>
<?

//DEVIL
$query = "SELECT * FROM d_tb_exp";
$result = mssql_query($query);
$d_exp = 0;
$d_wdhexp = 0;
$d_rdhexp = 0;
$d_exp = iConst_dexp / mssql_result($result,iConst_levelrow,"maxexp");
$d_rdexp = iConst_d_rdexp / mssql_result($result,iConst_levelrow,"rdexp");
$d_wdexp = iConst_d_wdexp / mssql_result($result,iConst_levelrow,"wdexp");
printf('Devil Exp:    %3.2f X,   (Res Death: %3.2f X, Warp Death: %3.2f X)', $d_exp, $d_rdexp, $d_wdexp);
?>
<br>
<?
// Retrieve con/cha from d_tb_inc_con and d_tb_inc_cha tables
$d_con = 0;
$d_cha = 0;

$query = "SELECT * FROM d_tb_inc_con";
$result = mssql_query($query);
$d_con = mssql_result($result,0,"con") / iConst_d_con;

$query = "SELECT * FROM d_tb_inc_cha";
$result = mssql_query($query);
$d_cha = mssql_result($result,0,"cha") / iConst_d_cha;

printf('Devil Con:    %3.2f X, Cha : %3.2f X)', $d_con, $d_cha);

?>
<br>
<?
// Retrieve Str, Dex, int and Wis from tb_inc table
$d_str = 0;
$d_dex = 0;
$d_int = 0;
$d_wis = 0;

$query = "SELECT * FROM d_tb_inc WHERE (sid LIKE '1')";
$result = mssql_query($query);
$d_str = mssql_result($result,0,"str") / iConst_d_str;
$d_dex = mssql_result($result,0,"dex") / iConst_d_dex;
$d_int = mssql_result($result,0,"int") / iConst_d_int;
$d_wis = mssql_result($result,0,"wis") / iConst_d_wis;

printf('Devil Str: %3.2f X, Dex: %3.2f X, Int: %3.2f X, Wis: %3.2f X )', $d_str, $d_dex, $d_int, $d_wis);
?>
<br>
<?

// Retrieve Skill items from tb_inc table
$d_axe = 0;
$d_bow = 0;
$d_knux = 0;
$d_spear= 0;
$d_staff = 0;
$d_sword= 0;

$d_darkmg= 0;
$d_whitemg = 0;
$d_bluemg= 0;

$query = "SELECT * FROM d_tb_inc_exp WHERE (sid LIKE '1')";
$result = mssql_query($query);
$d_axe = mssql_result($result,0,"axe") / iConst_d_weapon;
$d_bow = mssql_result($result,0,"bow") / iConst_d_weapon;
$d_knux = mssql_result($result,0,"knuckle") / iConst_d_weapon;
$d_spear = mssql_result($result,0,"spear") / iConst_d_weapon;
$d_staff = mssql_result($result,0,"staff") / iConst_d_weapon;
$d_sword = mssql_result($result,0,"sword") / iConst_d_weapon;

printf('Devil Skill - Axe: %3.2f X, Bow: %3.2f X, Knux: %3.2f X, Spear: %3.2f X, Staff: %3.2f X, Sword: %3.2f X )', $d_axe, $d_bow, $d_knux, $d_spear, $d_staff, $d_sword);

?>
<br>
<?
$d_darkmg = mssql_result($result,0,"darkmg") / iConst_d_magic;
$d_whitemg = mssql_result($result,0,"whitemg") / iConst_d_magic;
$d_bluemg = mssql_result($result,0,"bluemg") / iConst_d_magic;

printf('Devil Magic - Black: %3.2f X, White: %3.2f X, Blue: %3.2f X)', $d_darkmg, $d_whitemg, $d_bluemg);

?>
<p></p>
<p></p>
<?
echo "Rates in reference to Raged soma @ lvl 100";
?>
<p>
<h6>�Tiffany2007</h6>
</p>