                                                     
                                    88               
                                    ""               
                                                     
,adPPYYba,  8b,dPPYba,   ,adPPYba,  88  8b,     ,d8  
""     `Y8  88P'   "Y8  a8"     ""  88   `Y8, ,8P'   
,adPPPPP88  88          8b          88     )888(     
88,    ,88  88          "8a,   ,aa  88   ,d8" "8b,   
`"8bbdP"Y8  88           `"Ybbd8"'  88  8P'     `Y8  .eu



Soma Services Creator 


Before running the application ensure your config.ini file is correct 
only those settings in the [config] section 
are essential to services setup the attributes are as follows:

Capacity : The amount of players your server can hold
IP: Your LAN IP if you are behind a NAT your WAN if you are not 
ODBC: The name of your ODBC Connection 
Password: The password for your mssql user
Username: The username for your mssql user 
Service Name: the name you wish to give to your services 
Service Path: the path to your services folder found in your server files

A default config.ini is included so you can see how to input the values 
If the program doesn't seem to be deleting or creating, try closing the program and reopening it 
as there is a known issue involved with trying to create or delete twice. 


Credits:
Remix, Miser, ArbaXbus for helping me with issues/testing created by arcanine. 




